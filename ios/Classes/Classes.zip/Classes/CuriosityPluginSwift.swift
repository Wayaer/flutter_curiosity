import Flutter
import UIKit

public class CuriosityPluginSwift: NSObject, FlutterPlugin {
    
    public static func register(with registrar: FlutterPluginRegistrar) {
        let channel = FlutterMethodChannel(name: "Curiosity", binaryMessenger: (registrar.messenger()))
        registrar.addMethodCallDelegate(CuriosityPluginSwift(), channel: channel)
        registrar.register(ScannerFactory(messenger: registrar.messenger())!, withId: "scanner")
        
    }
    
    
    public func handle(_ call: FlutterMethodCall, _ result: @escaping FlutterResult) {
        gallery(call,result)
        scanner(call,result)
        utils(call, result)
    }
    
    
    func gallery(_ call :FlutterMethodCall, _ result: FlutterResult) {
//        let viewController = UIApplication.shared.delegate?.window?!.rootViewController!
        if ("openPicker" == call.method) {
//            PicturePicker.openPicker(call, viewController: viewController, result: result)
        } else if ("openCamera" == call.method) {
            //            PicturePicker.openCamera(call, viewController: viewController, result: result)
        } else if ("deleteCacheDirFile" == call.method) {
            PicturePicker.deleteCacheDirFile()
        }
    }
    func scanner(_ call :FlutterMethodCall, _ result: FlutterResult) {
        
        if ("scanImagePath" == call.method) {
            //            ScannerUtils.scanImagePath(call, result)
        } else if ("scanImageUrl" == call.method) {
            //            ScannerUtils.scanImageUrl(call, result: result)
        }else if ("scanImageMemory" == call.method) {
            //            ScannerUtils.scanImageMemory(call, result: result)
        }
    }
    func utils(_ call:FlutterMethodCall, _ result: FlutterResult) {
        let arguments=call.arguments as! [AnyHashable : Any]
        
        if ("getFilePathSize" == call.method) {
            result(FileUtils.getFilePathSize(arguments["filePath"] as! String))
        } else if ("deleteDirectory" == call.method) {
            FileUtils.deleteDirectory(arguments["directoryPath"] as! String)
            result("success")
        } else if ("deleteFile" == call.method) {
            FileUtils.deleteFile(arguments["filePath"]as! String)
            result("success")
        } else if ("unZipFile" == call.method) {
            result(FileUtils.unZipFile((arguments["filePath"]as? String)!))
        } else if ("goToMarket" == call.method) {
            NativeUtils.goToMarket(arguments["packageName"] as! String )
            result("success")
        }  else if ("getAppInfo" == call.method) {
            result(NativeUtils.getAppInfo())
        } else if ("getDirectoryAllName" == call.method) {
            result(FileUtils.getDirectoryAllName(arguments["path"] as! String))
        } else if ("callPhone" == call.method) {
            NativeUtils.callPhone(arguments["phoneNumber"] as? String, arguments["directDial"] as! Bool)
            result("success")
        } else if ("exitApp" == call.method) {
            exit(0)
        }
        
    }
    
    
}
