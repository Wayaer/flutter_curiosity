#import "CuriosityPlugin.h"
#if __has_include(<flutter_curiosity/flutter_curiosity-Swift.h>)
#import <flutter_curiosity/flutter_curiosity-Swift.h>
#else

#import "Curiosity-Brdging-Header.h"
#endif
//#import "ScannerUtils.h"
//#import "ScannerFactory.h"
//#import "PicturePicker.h"


@implementation CuriosityPlugin

+ (void)registerWithRegistrar:(NSObject<FlutterPluginRegistrar>*)registrar {
    [CuriosityPluginSwift registerWithRegistrar:registrar];
}
@end
//    FlutterMethodChannel* channel = [FlutterMethodChannel
//                                      methodChannelWithName:@"Curiosity"
//                                      binaryMessenger:[registrar messenger]];
//     UIViewController *viewController =
//     [UIApplication sharedApplication].delegate.window.rootViewController;
//     CuriosityPlugin* instance = [[CuriosityPlugin alloc] initWithViewController:viewController];
//     [registrar addMethodCallDelegate:instance channel:channel];
//     ScannerFactory * scanner=[[ScannerFactory alloc]initWithMessenger:[registrar messenger]];
//
//     [registrar registerViewFactory:scanner withId:@"scanner"];
//}
//- (instancetype)initWithViewController:(UIViewController *)_viewController {
//    self = [super init];
//    if (self) {
//        viewController = _viewController;
//    }
//    return self;
//}
//- (void)handleMethodCall:(FlutterMethodCall*)_call result:(FlutterResult)result {
//    call=_call;
//    [self gallery:result];
//    [self scanner:result];
//    [self utils:result];
//
//}
//
//-(void)gallery:(FlutterResult)result{
//    if ([@"openPicker" isEqualToString:call.method]) {
//        [PicturePicker openPicker:call.arguments viewController:viewController result:result];
//    } else if ([@"openCamera" isEqualToString:call.method]) {
//        [PicturePicker openCamera:call.arguments viewController:viewController result:result];
//    } else if ([@"deleteCacheDirFile" isEqualToString:call.method]) {
//        [PicturePicker deleteCacheDirFile];
//    }
//}
//-(void)scanner:(FlutterResult)result{
//    if ([@"scanImagePath" isEqualToString:call.method]) {
//        [ScannerUtils scanImagePath:call result:result];
//    }else if ([@"scanImageUrl" isEqualToString:call.method]) {
//        [ScannerUtils scanImageUrl:call result:result];
//    }if ([@"scanImageMemory" isEqualToString:call.method]) {
//        [ScannerUtils scanImageMemory:call result:result];
//    }
//}
//-(void)utils:(FlutterResult)result{
//    FileUtils *fileUtils = [[FileUtils alloc] init];
//     if ([@"getAppInfo" isEqualToString:call.method]) {
//         result([AppInfo getAppInfo]);
//     }else if([@"getDirectoryAllName" isEqualToString:call.method]){
//         result([FileUtils getDirectoryAllName:call.arguments]);
//     }else if ([@"getFilePathSize" isEqualToString:call.method]) {
//        result([FileUtils getFilePathSize:call.arguments[@"filePath"]]);
//    } else if ([@"deleteDirectory" isEqualToString:call.method]) {
//        [FileUtils deleteDirectory:call.arguments[@"directoryPath"]];
//        result( @"success");
//    } else if ([@"deleteFile" isEqualToString:call.method]) {
//        [FileUtils deleteFile:call.arguments[@"filePath"]];
//        result( @"success");
//    } else if ([@"unZipFile" isEqualToString:call.method]) {
//        [FileUtils unZipFile:call.arguments[@"filePath"]];
//        result( @"success");
//    }else if ([@"goToMarket" isEqualToString:call.method]) {
//        [NativeUtils goToMarket:call.arguments[@"packageName"]];
//        result( @"success");
//    } else if ([@"callPhone" isEqualToString:call.method]) {
//        [NativeUtils callPhone:call.arguments[@"phoneNumber"] :call.arguments[@"directDial"]];
//        result( @"success");
//    } else if ([@"exitApp" isEqualToString:call.method]) {
//        exit(0);
//    }
//}


