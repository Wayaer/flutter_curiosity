#import <Flutter/Flutter.h>

@interface CuriosityPlugin : NSObject<FlutterPlugin>
@end
