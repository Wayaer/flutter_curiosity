import Foundation
import UIKit

class NativeUtils  {
    //获取app信息
    
    class func getAppInfo() -> [AnyHashable : Any]? {
        let app = Bundle.main.infoDictionary
        let statusBar = UIApplication.shared.statusBarFrame
        let device = UIDevice.current
        let  info: [AnyHashable : Any] = [
            
            AnyHashable("statusBarHeight") : NSNumber(value: Float(statusBar.size.height)),
            AnyHashable("statusBarWidth") : NSNumber(value: Float(statusBar.size.width)),
            
            AnyHashable("homeDirectory") : NSHomeDirectory(),
            AnyHashable("documentDirectory") : NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask, true).first as Any,
            AnyHashable("libraryDirectory") : NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.libraryDirectory, FileManager.SearchPathDomainMask.userDomainMask, true).last as Any,
            AnyHashable("cachesDirectory") : NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.cachesDirectory, FileManager.SearchPathDomainMask.userDomainMask, true).first as Any,
            AnyHashable("temporaryDirectory") : NSTemporaryDirectory(),
            
            AnyHashable("versionName") : app?["CFBundleShortVersionString"] as Any,
            AnyHashable("phoneBrand") : "Apple",
            AnyHashable("versionCode") : NSNumber(value: Int32((app?["CFBundleVersion"] as? NSNumber)?.intValue ?? 0)),
            
            AnyHashable("packageName") : app?["CFBundleIdentifier"] as Any,
            AnyHashable("appName") : app?["CFBundleName"] as Any,
            AnyHashable("sdkBuild") : app?["DTSDKBuild"] as Any,
            AnyHashable("platformName") : app?["DTPlatformName"] as Any,
            AnyHashable("pinimumOSVersion") : app?["MinimumOSVersion"] as Any,
            AnyHashable("platformVersion") : app?["DTPlatformVersion"] as Any,
            
            AnyHashable("systemName") : device.systemName,
            AnyHashable("systemVersion") : device.systemVersion,
        ]
        
        return info
    }
    
    //Log
    class  func log(_ info: Any?) {
        if let info = info {
            print("Curiosity--- \(info)")
        }
    }
    
    //跳转到AppStore
    class func goToMarket(_ id: String) {
        let url = "itms-apps://itunes.apple.com/us/app/id"+id
        UIApplication.shared.openURL(URL(string: url)!)
        
    }


    class func callPhone(_ phoneNumber: String?, _ directDial: Bool) {
        if directDial {
            if let url = URL(string: "tel://" + (phoneNumber ?? "")) {
                UIApplication.shared.openURL(url)
            }
        } else {
            let callWebview = UIWebView()
            if let url = URL(string: "tel:" + (phoneNumber ?? "")) {
                callWebview.loadRequest(URLRequest(url: url))
            }
            UIApplication.shared.keyWindow?.addSubview(callWebview)
        }
        
    }
    
}
